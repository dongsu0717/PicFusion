package com.dongsu.presentation.ui.overlay

import androidx.lifecycle.viewModelScope
import com.dongsu.domain.repository.AlbumRepository
import com.dongsu.domain.repository.FolderRepository
import com.dongsu.presentation.base.BaseViewModel
import com.dongsu.presentation.ui.overlay.intent.EditEvent
import com.dongsu.presentation.ui.overlay.state.EditState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class EditViewModel @Inject constructor(
    private val folderRepository: FolderRepository,
    private val albumRepository: AlbumRepository
):BaseViewModel<EditState, EditEvent>(EditState()) {

    override suspend fun handleEvent(event: EditEvent) {
        when(event){
            is EditEvent.LoadSvg -> loadSvg()
            is EditEvent.SavePhoto -> savePhoto(event.photo)
        }
    }


    private fun savePhoto(photoToSave: String) {
        updateUiState { copy(isLoading = true) }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                albumRepository.savePhoto(photoToSave)
                    .onSuccess {
                        updateUiState { copy(isLoading = false, isPhotoSaved = true) }
                    }
                    .onFailure {
                        updateUiState { copy(isLoading = false, error = it) }
                    }
            }
        }
    }

    private fun loadSvg() {
        updateUiState { copy(isLoading = true) }
        viewModelScope.launch {
            folderRepository.loadAllAssetsFile()
                .onSuccess {
                    updateUiState { copy(isLoading = false, svgList = it) }
                }
                .onFailure {
                    updateUiState { copy(isLoading = false, error = it) }
                }
        }
    }

}
