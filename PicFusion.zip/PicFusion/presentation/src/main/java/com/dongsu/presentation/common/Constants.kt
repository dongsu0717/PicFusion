package com.dongsu.presentation.common


const val THUMBNAIL_IMAGE_WIDTH = 100
const val THUMBNAIL_IMAGE_HEIGHT = 100

const val UTF_8 = "UTF-8"

//photo picker
const val PHOTO_LIST_CELL = 3
