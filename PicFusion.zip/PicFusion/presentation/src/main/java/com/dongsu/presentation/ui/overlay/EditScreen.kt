package com.dongsu.presentation.ui.overlay

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.dongsu.presentation.R
import com.dongsu.presentation.common.bitmapToString
import com.dongsu.presentation.common.checkWritePermission
import com.dongsu.presentation.common.combineImages
import com.dongsu.presentation.common.convertSvgToBitmap
import com.dongsu.presentation.common.stringToBitmap
import com.dongsu.presentation.navigation.Destination
import com.dongsu.presentation.ui.components.MainTopAppBar
import com.dongsu.presentation.ui.components.SaveButton
import com.dongsu.presentation.ui.overlay.content.SvgRowContent
import com.dongsu.presentation.ui.overlay.intent.EditEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun EditScreen(
    navController: NavController,
    photoUri: String?
) {
    val editViewModel: EditViewModel = hiltViewModel()
    val state by editViewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectPhoto: Bitmap? by remember { mutableStateOf(null) }
    var combinedBitmap: Bitmap? by remember { mutableStateOf(null) }
    var svgBitmapList: List<Bitmap>? by remember { mutableStateOf(listOf()) }

    LaunchedEffect(Unit) {
        editViewModel.onEvent(EditEvent.LoadSvg)
    }

    LaunchedEffect(state.svgList) {
        svgBitmapList = withContext(Dispatchers.IO) {
            state.svgList.mapNotNull { asset ->
                convertSvgToBitmap(context, asset.content)
            }
        }
    }

    LaunchedEffect(Unit) {
        photoUri?.let {
            selectPhoto = stringToBitmap(it)
        }
    }


    when{
        state.isPhotoSaved -> {
            navController.navigate(Destination.Album.route)
        }
    }

    Scaffold(
        topBar = {
            MainTopAppBar(
                title = "수정 조져",
                showBackButton = true,
                navController = navController,
                saveButton = {
                    SaveButton(
                        onClick = {
                            if(checkWritePermission(context)) {
                                saveCombinedBitmap(combinedBitmap, editViewModel)
                            }
                        }
                    )
                }
            )
        }
    ){paddingValues ->
        Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues) // 패딩 추가
        ) {
            if(combinedBitmap == null) {
                selectPhoto?.let {
                    Image(
                        bitmap = it.asImageBitmap(),
                        contentDescription = "Main Image",
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(dimensionResource(R.dimen.large_padding))
                            .weight(1f)
                    )
                }
            } else {
                Image(
                    bitmap = combinedBitmap!!.asImageBitmap(),
                    contentDescription = "합성",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(dimensionResource(R.dimen.large_padding)),
                    )
            }
            SvgRowContent(
               svgBitmapList,
                onClick = { selectSvg ->
                    selectPhoto?.let {
                        combinedBitmap = combineImages(it, selectSvg)
                    }
                }
            )
        }
    }
}

private fun saveCombinedBitmap(
    combinedBitmap: Bitmap?,
    viewModel: EditViewModel,
) {
    combinedBitmap?.let { bitmap ->
        val photoToString = bitmapToString(combinedBitmap)
        viewModel.onEvent(EditEvent.SavePhoto(photoToString))
    }
}

