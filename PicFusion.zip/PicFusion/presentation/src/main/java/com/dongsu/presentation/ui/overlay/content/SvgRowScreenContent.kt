package com.dongsu.presentation.ui.overlay.content

import android.graphics.Bitmap
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.dongsu.presentation.ui.components.SvgWithFrameBox

@Composable
fun SvgRowContent(
    svgBitmap: List<Bitmap>?,
    onClick: (Bitmap) -> Unit
){
    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(30.dp)
    ) {
        svgBitmap?.let {svgList ->
            items(svgList.size) { svg ->
                SvgWithFrameBox(
                    svgBitmap[svg],
                    onClick = { onClick(svgList[svg]) }
                )
            }
        }
    }
}