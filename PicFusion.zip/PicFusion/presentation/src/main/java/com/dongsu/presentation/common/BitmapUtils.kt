package com.dongsu.presentation.common

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.util.Base64
import androidx.core.graphics.drawable.toBitmap
import coil.ImageLoader
import coil.decode.SvgDecoder
import coil.request.ImageRequest
import coil.request.SuccessResult
import timber.log.Timber
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

fun bitmapToString(bitmap: Bitmap): String {
    val byteArrayOutputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
    val bytes = byteArrayOutputStream.toByteArray()
    val temp: String = Base64.encodeToString(bytes, Base64.DEFAULT)
    return temp
}

fun stringToBitmap(encodedString: String): Bitmap? =
    try {
        if (encodedString.startsWith("/storage")) {
            val bitmap = BitmapFactory.decodeFile(encodedString)
            bitmap
        } else {
            val encodeByte: ByteArray = Base64.decode(encodedString, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.size)
            bitmap
        }
    } catch (e: Exception) {
        Timber.e(e)
        null
    }

suspend fun convertSvgToBitmap(context: Context, svgUri: String): Bitmap? {

    val loader = ImageLoader.Builder(context)
        .components {
            add(SvgDecoder.Factory())
        }
        .build()

    val tempFile = File(context.cacheDir, "temp.svg")
    FileOutputStream(tempFile).use { outputStream ->
        outputStream.write(svgUri.toByteArray())
    }

    val request = ImageRequest.Builder(context)
        .data(tempFile)
        .build()

    val result = loader.execute(request)
    return if (result is SuccessResult) {
        Timber.e("성공!!!!!!!!")
        result.drawable.toBitmap()
    } else {
        Timber.e("실패!!!!!!!!")
        null
    }
}

fun combineImages(baseBitmap: Bitmap, overlayBitmap: Bitmap): Bitmap {
    val combinedBitmap = Bitmap.createBitmap(
        baseBitmap.width,
        baseBitmap.height,
        baseBitmap.config
    )
    val canvas = Canvas(combinedBitmap)
    canvas.drawBitmap(baseBitmap, 0f, 0f, null)

    val left = (baseBitmap.width - overlayBitmap.width) / 2f
    val top = (baseBitmap.height - overlayBitmap.height) / 2f
    canvas.drawBitmap(overlayBitmap, left, top, Paint())

    return combinedBitmap
}
