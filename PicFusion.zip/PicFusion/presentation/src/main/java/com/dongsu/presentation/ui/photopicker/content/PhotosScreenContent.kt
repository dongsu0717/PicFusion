package com.dongsu.presentation.ui.photopicker.content

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.dimensionResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import com.dongsu.domain.model.Photo
import com.dongsu.presentation.R
import com.dongsu.presentation.common.PHOTO_LIST_CELL
import com.dongsu.presentation.common.THUMBNAIL_IMAGE_HEIGHT
import com.dongsu.presentation.common.THUMBNAIL_IMAGE_WIDTH
import com.dongsu.presentation.common.UTF_8
import com.dongsu.presentation.navigation.Destination
import com.dongsu.presentation.ui.components.MainTopAppBar
import java.net.URLEncoder

@Composable
fun PhotosScreenContent(
    photoList: List<Photo>,
    albumName: String?,
    navController: NavController
){
    Scaffold(
        topBar = {
            MainTopAppBar(
                navController = navController,
                title = albumName!!,
                showBackButton = true
            )
        }
    ){paddingValues ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(PHOTO_LIST_CELL),
            modifier = Modifier.padding(paddingValues),
            contentPadding = PaddingValues(dimensionResource(R.dimen.grid_content_padding)),
            verticalArrangement = Arrangement.spacedBy(dimensionResource(R.dimen.default_padding))
        ){
            items(photoList) { photo ->
                Image(
                    painter = rememberAsyncImagePainter(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(photo.uri)
                            .size(THUMBNAIL_IMAGE_WIDTH, THUMBNAIL_IMAGE_HEIGHT)
                            .build()
                    ),
                    contentDescription = null,
                    modifier = Modifier
                        .padding(dimensionResource(R.dimen.small_padding))
                        .size(100.dp)
                        .aspectRatio(1f)
                        .clickable {
                            val encodedPhotoUri = URLEncoder.encode(photo.uri, UTF_8)
                            navController.navigate(Destination.Edit.route + "/$encodedPhotoUri")
                        },
                    contentScale = ContentScale.Crop
                )
            }
        }
    }
}