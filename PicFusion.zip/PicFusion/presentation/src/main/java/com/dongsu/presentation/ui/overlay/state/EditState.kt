package com.dongsu.presentation.ui.overlay.state

import com.dongsu.domain.model.Asset

data class EditState (
    val isLoading: Boolean = false,
    val svgList: List<Asset> = emptyList(),
    val isPhotoSaved: Boolean = false,
    val error: Throwable? = null
)