package com.dongsu.presentation.ui.overlay.intent

sealed class EditEvent {
    data object LoadSvg : EditEvent()
    data class SavePhoto(val photo: String) : EditEvent()
}
