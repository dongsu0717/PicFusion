package com.dongsu.presentation.ui.components

import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.painterResource
import androidx.navigation.NavController
import com.dongsu.presentation.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTopAppBar(
    navController: NavController,
    title: String,
    showBackButton: Boolean = false,
    saveButton: @Composable (() -> Unit)? = null,
) {
    TopAppBar(
        title = {
            Text(text = title)
        },

        navigationIcon = {
            if (showBackButton) {
                IconButton(
                    onClick = { navController.popBackStack() }
                ) {
                    Icon(
                        painter = painterResource(R.drawable.back_btn),
                        contentDescription = "Back"
                    )
                }
            }
        },
        actions = {
            saveButton?.invoke()
        }
    )
}