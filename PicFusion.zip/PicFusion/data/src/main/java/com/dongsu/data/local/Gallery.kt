package com.dongsu.data.local

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.contentValuesOf
import com.dongsu.data.utils.stringToBitmap
import com.dongsu.domain.model.Album
import com.dongsu.domain.model.Photo
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject

class Gallery @Inject constructor(
    private val context: Context,
) {

    fun getAlbums(): List<Album> {
        var albumList = mutableListOf<Album>()

        val albumMap = mutableMapOf<Int, MutableList<String>>()
        val albumNameMap = mutableMapOf<Int, String>()
        val allPhotos = mutableListOf<String>()

        getAlbumCursor()?.use {
            val albumIdColumn = it.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
            val albumNameColumn =
                it.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
            val photoUriColumn = it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)

            while (it.moveToNext()) {
                val albumId = it.getInt(albumIdColumn)
                val albumName = it.getString(albumNameColumn)
                val photoUri = it.getString(photoUriColumn)

                allPhotos.add(photoUri)
                albumMap.getOrPut(albumId) { mutableListOf() }.add(photoUri)
                albumNameMap[albumId] = albumName
            }
        }

        albumList = albumMap.map { (albumId, photoPaths) ->
            Album(
                albumId = albumId,
                albumCoverUrl = photoPaths.firstOrNull() ?: "",
                albumName = albumNameMap[albumId] ?: "Unknown",
                photoCount = photoPaths.size
            )
        }.toMutableList()

        val recentAlbum = Album(
            albumId = -1,
            albumCoverUrl = allPhotos.firstOrNull() ?: "",
            albumName = "최근항목",
            photoCount = allPhotos.size
        )
        albumList.add(0, recentAlbum)
        return albumList
    }

    fun getAllPhotos(): List<Photo>{
        val photoList = mutableListOf<Photo>()


        return photoList
    }

    fun getPhotos(albumId: String): List<Photo> {
        val photoList = mutableListOf<Photo>()
        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media.BUCKET_ID,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.DATA
        )
        val selection = "${MediaStore.Images.Media.BUCKET_ID} = ?"
        val selectionArgs = arrayOf(albumId)
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

        context.contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
            ?.use { cursor ->
                val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)

                while (cursor.moveToNext()) {
                    val photoUri = cursor.getString(dataColumn)
                    photoList.add(Photo(uri = photoUri))
                }
            }

        return photoList
    }

    fun savePhotoAfterApi29(photoToSave: String) {

        val bitmap = stringToBitmap(photoToSave)

        val contentValues = contentValuesOf(
            MediaStore.Images.Media.DISPLAY_NAME to "pixo_combined_image.png",
            MediaStore.Images.Media.MIME_TYPE to "image/png",
            MediaStore.Images.Media.RELATIVE_PATH to Environment.DIRECTORY_PICTURES
        )

        val contentResolver = context.contentResolver
        val uri = contentResolver
            .insert(
                getExternalContentUri(),
                contentValues
            )
        uri?.let { outputUri ->
            contentResolver.openOutputStream(outputUri).use { outputStream ->
                if (outputStream != null) {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                }
            }
        }
    }

    fun savePhotoUnderApi29(photoToSave: String) {
        val bitmap = stringToBitmap(photoToSave)

        val pictureFolder = Environment.getExternalStorageDirectory().toString() +
                "/" + Environment.DIRECTORY_PICTURES
        val savePath = "$pictureFolder/pixo"
        val imageFolder = File(savePath).apply {
            if (!isDirectory) mkdirs()
        }

        val completeFileName = "/pixo.jpg"
        FileOutputStream(savePath + completeFileName).use {outputStream ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
        }
        scanPhoto(context, imageFolder.absolutePath + completeFileName)
    }

    @Suppress("DEPRECATION")
    private fun scanPhoto(context: Context, imagePath: String) {
        val intent = Intent(
            Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
            Uri.parse("file://$imagePath")
        )
        context.sendBroadcast(intent)
    }

    private fun getAlbumCursor(): Cursor? {
        val externalUri = getExternalContentUri()
        val projection = getProjection()
        val sortOrder = getSelection()
        return context.contentResolver.query(
            externalUri,
            projection,
            null,
            null,
            sortOrder
        )
    }

    private fun getExternalContentUri() = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    private fun getProjection() = arrayOf(
        MediaStore.Images.Media.BUCKET_ID,
        MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
        MediaStore.Images.Media.DATA
    )

    private fun getSelection() = "${MediaStore.Images.Media.DATE_ADDED} DESC"
}

