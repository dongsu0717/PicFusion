package com.dongsu.data.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.IOException

fun stringToBitmap(encodedString: String): Bitmap {
    try {
        val encodeByte: ByteArray = Base64.decode(encodedString, Base64.DEFAULT)
        val bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.size)
        return bitmap
    } catch (e: Exception) {
        throw IOException("비트맵으로 변환 실패", e)
    }
}

fun bitmapToString(bitmap: Bitmap): String {
    val byteArrayOutputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
    val bytes = byteArrayOutputStream.toByteArray()
    val temp: String = Base64.encodeToString(bytes, Base64.DEFAULT)
    return temp
}