package com.dongsu.data.datasource

import android.os.Build
import com.dongsu.data.local.Gallery
import com.dongsu.domain.model.Album
import com.dongsu.domain.model.Photo
import javax.inject.Inject

class AlbumLocalDataSourceImpl @Inject constructor(
    private val gallery: Gallery
): AlbumLocalDataSource {
    override suspend fun loadAlbums(): List<Album> =
        gallery.getAlbums()

    override suspend fun loadPhotos(albumId: String): List<Photo> =
        gallery.getPhotos(albumId)

    override suspend fun savePhoto(photoToSave: String): Unit =
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q){
            gallery.savePhotoAfterApi29(photoToSave)
        } else {
            gallery.savePhotoUnderApi29(photoToSave)
        }

}