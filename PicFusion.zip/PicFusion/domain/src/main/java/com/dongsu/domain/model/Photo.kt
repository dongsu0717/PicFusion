package com.dongsu.domain.model

data class Photo(
    val uri: String
)
