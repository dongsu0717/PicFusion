package com.dongsu.domain.model

data class Album(
    val albumId: Int,
    val albumCoverUrl: String,
    val albumName: String,
    val photoCount: Int
)
