package com.dongsu.domain.model

data class Asset(
    val content: String,
)
